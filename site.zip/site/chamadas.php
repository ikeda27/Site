<?
	/* ENVIAR INPUT  */
	private function call($user, $pass, $tipo, $campos, $campos_select, $dados, $table, $criterios){
		/* hash md5 inputs */
		$user_ok 		   = dec( $user );
		$pass_ok  		   = dec( $pass );
		$tipo_ok  		   = dec( $tipo );
		$campos_ok 		   = dec( $campos );
		$campos_select_ok  = dec( $campos_select );
		$dados_ok 	  	   = dec( $dados );
		$table_ok  	  	   = dec( $table );
		$criterios_ok 	   = dec( $criterios );
		
		/* DEFINIR CONEXÃO  */
		$pdo = new PDO('mysql:host=C:\Users\Projeto\Desktop\BD_PROJETO;dbname=TESTE', $user, $pass);
		/* PRIMEIRO USER NA RAÇA */
		
		
		/* INSTANCIAR CONEXÃO  */
		switch $tipo
		/* REALIZA AÇÃO C.R.U.D. */
		/* INSERE DADOS */
		case 1: $stmt = $pdo->prepare('INSERT INTO' & $table & ' ' & $campos & ' ' & $dados );
		/* ATUALIZA DADOS */
		case 2: $stmt = $pdo->prepare('UPDATE SET' & $campos_select & ' = ' & $dados & ' WHERE ' & $campos & ' = ' & $criterios);
		/* DELETA DADOS */
		case 3: $stmt = $pdo->prepare('DELETE * FROM ' & $table & ' WHERE ' & $campos & ' = ' & $criterios);
		/* EXTRAI DADOS */
		else:   $stmt = $pdo->prepare('SELECT '& $campos_select &' FROM ' & $table & ' WHERE ' & $campos & ' = ' & $criterios);
		
		sleep(0.001);
		
		/* EXECUTA CÓDIGO */
		$stmt->execute();
		
		/* FECHA CONEXÃO  */
		$pdo = null;
		sleep(60);
	}
	
	private function teste (){
		$input = "SmackFactory";

		$encrypted = encryptIt( $input );
		

		echo $encrypted . '<br />' . $decrypted;

		function ec( $q ) {
			$cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
			$qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
			return( $qEncoded );
		}

		function dec( $q ) {
			$cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
			$qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
			return( $qDecoded );
		}
	}
	

	/* RECEBER INPUT  */
	private function rest($tipo, $dados){
		/* VERIFICA ASSINATURA DO RETORNO */
		/* hash md5 */
		$tipo_ok  = dec( $tipo );
		$dados_ok = dec( $dados );
		
		/* quebrar array $dados, trazer usuario */
		switch $tipo
		/* INSERE DADOS */
		case 1: $msg = 'CADASTRO DO USUÁRIO ' & $dados_ok[user] & ' REALIZADO !' );
		/* ATUALIZA DADOS */
		case 2: $msg = 'INFORMAÇÕES DO USUÁRIO ' & $dados_ok[user] & ' ATUALIZADOS !' );
		/* DELETA DADOS */
		case 3: $msg = 'USUÁRIO ' & $dados_ok[user] & ' REMOVIDO !' );
		/* EXTRAI DADOS FOR EACH $dados */
		else:   $msg = 'CONSULTA DO USUÁRIO ' & $dados_ok[user] & ': ' & $dados_ok);
		
		/* EXIBE RETORNO DE DADOS */
		
		/* REFERENCIAR MODAL */
		
		/* "JOGAR" DADOS NO MODAL */
	}

?>