﻿<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Página para realizar login">
    <meta name="author" content="Cesar">
    <link rel="icon" href="imagens/favicon.ico">

    <title>Listar torneio</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>

  </head>
<?php
	include_once("conexao.php");
	$resultado=mysqli_query($conectar,"SELECT * FROM cadastro_torneio ORDER BY 'cod_cadastro_torneio'");
	$linhas=mysqli_num_rows($resultado);
?>	
<div class="container theme-showcase" role="main">      
  <div class="page-header">
	<h1>Lista de Torneio</h1>
  </div>
  <div class="row espaco">
		<div class="pull-right">
			<a href="administrativo.php?link=41"><button type='button' class='btn btn-sm btn-success'>Cadastrar</button></a>
		</div>
	</div>
  <div class="row">
	<div class="col-md-12">
	  <table class="table">
		<thead>
		  <tr>
			<th>Codigo Torneio</th>
			<th>Nome Torneio</th>
			<th>Torneio Rankeado</th>
			<th>Tipo do Torneio</th>
			<th>Peso Torneio</th>
			<th>Valor Entrada</th>
			<th>Qtde Máx. Rebuy</th>
			<th>Valor Rebuy</th>
			<th>Qtde Máx. Addon</th>			
			<th>Valor Addon</th>
			<th>Qtde Máx. Players Mesa</th>			
		  </tr>
		</thead>
		<tbody>
			<?php 
				while($linhas = mysqli_fetch_array($resultado)){
					echo "<tr>";
						echo "<td>".$linhas['cod_cadastro_torneio']."</td>";
						echo "<td>".$linhas['nome_torneio']."</td>";
						echo "<td>".$linhas['flg_ranking']."</td>";
						echo "<td>".$linhas['tipo_torneio']."</td>";
						echo "<td>".$linhas['peso_torneio']."</td>";
						echo "<td>".$linhas['vlr_entrada']."</td>";
						echo "<td>".$linhas['qtd_max_rebuy']."</td>";
						echo "<td>".$linhas['vlr_rebuy']."</td>";
						echo "<td>".$linhas['qtd_max_addon']."</td>";
						echo "<td>".$linhas['vlr_addon']."</td>";
						echo "<td>".$linhas['qtd_max_player_mesa']."</td>";
						?>
						<td> 
						<a href='administrativo.php?link=5&id=<?php echo $linhas['cod_cadastro_torneio']; ?>'><button type='button' class='btn btn-sm btn-primary'>Visualizar</button></a>
						
						<a href='administrativo.php?link=43&id=<?php echo $linhas['cod_cadastro_torneio']; ?>'><button type='button' class='btn btn-sm btn-warning'>Editar</button></a>
						
						<a href='processa/proc_apagar_torneio.php?id=<?php echo $linhas['cod_cadastro_torneio']; ?>'><button type='button' class='btn btn-sm btn-danger'>Apagar</button></a>
						
						<?php
					echo "</tr>";
				}
			?>
		</tbody>
	  </table>
	</div>
	</div>
</div> <!-- /container -->

